function snacks() {
    return "mars bars,\nchocolate cake,\negg tart";
}

module.exports = snacks;