function registration(studentName, courseCode, courseName) {
    return `You have registered for the course ${courseCode}, ${courseName} with the teacher ${studentName}.`;
}

module.exports = registration;